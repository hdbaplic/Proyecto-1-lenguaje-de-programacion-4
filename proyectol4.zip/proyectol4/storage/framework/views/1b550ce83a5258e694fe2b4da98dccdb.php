
<?php $__env->startSection('contenido'); ?>

<h1>Proyecto <?php echo e($project->nombre); ?> </h1>
<div class="container">
    <div class="row">
        <div class="col">
            <div class="card" style="width: 80rem;">
                <div class="card-body">
                  <h5 class="card-title"><strong>Nombre:  </strong><?php echo e($project->nombre); ?></h5>
                  <p class="card-text"><strong>Descripción: </strong> <br><?php echo e($project->descripcion); ?></p>
                  <p class="card-text"><strong>Estado: </strong><?php echo e($project->estado); ?></p>
                  <p class="card-text">
                      <strong>Archivo:</strong> 
                      <a href="<?php echo e(route('projects.show', ['project' => $project->id])); ?>">Ver Proyecto</a>
                  </p>
                
                
                </div>
              </div>
        </div>
    </div>
</div>



<div class="container">
    <h2>Lista de comentarios</h2>
   
    <table class="table">
        <thead>
            <tr>
                <th>Comentario</th>
                <th>Nombre</th>
                <th>Id de usuario</th>
                <th>Id de proyecto</th>
                
               
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $project->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($comentario->contenido); ?></td>
                <td><?php echo e($comentario->name); ?></td>
                <td><?php echo e($comentario->id); ?></td>
                <td><?php echo e($comentario->id); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">No hay comentarios</td>
                </tr>
            
            <?php endif; ?>
        </tbody>
        
    </table>
        
   
</div>
<a href="<?php echo e(route('projects.index')); ?>" class="btn btn-primary">Volver</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyectol4\resources\views/project/show.blade.php ENDPATH**/ ?>