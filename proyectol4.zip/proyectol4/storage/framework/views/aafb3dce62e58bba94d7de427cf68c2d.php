
<?php $__env->startSection('contenido'); ?>

<?php if(isset($project)): ?>
<h1>Editar Proyecto <?php echo e($project->nombre); ?> <a class="btn btn-success" href="<?php echo e(route('projects.index')); ?>">Volver</a></h1>
<?php else: ?>
<h1>Crear un Nuevo Proyecto <a class="btn btn-success" href="<?php echo e(route('projects.index')); ?>">Volver</a></h1>
<?php endif; ?>
<div class="container">
<!-- Mensajes de error sobre la validación -->
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>



    
<!-- Formulario para crear un proyecto y subir un archivo -->
<form class="form-floating" method="post" enctype="multipart/form-data">
    
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_method" value="PUT">
    <?php if(isset($project)): ?>
    <?php echo method_field('put'); ?>
    <?php endif; ?>

   
    <div class="form-floating mb-3">
        <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre del producto" value="<?php echo e(isset($project) ? $project->nombre : old('nombre')); ?>">
        <label for="nombre">Nombre del proyecto</label>
    </div>

    <div class="row">
        <div class="col">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion" value="<?php echo e(isset($project) ? $project->descripcion : old('descripcion')); ?>">
                <label for="descripcion">Descripcion</label>
            </div>
        </div>
        <div class="col">

            <div class="form-floating mb-3">
                
                <select name="estado" id="estado" class="form-select" required>
                    <option value="activo" <?php echo e(isset($project) && $project->estado == 'activo' ? 'selected' : ''); ?> placeholder="Estado">Activo</option>
                    <option value="completado" <?php echo e(isset($project) && $project->estado == 'completado' ? 'selected' : ''); ?>>Completado</option>
                </select>
                <label for="estado">Estado</label>
            </div>
        </div>
        <div class="col">
            <div class="form-floating mb-3">
                <input type="file" class="form-control" id="file" name="ruta" placeholder="Documento a subir" value="<?php echo e(isset($project) ? $project->ruta : old('ruta')); ?>">
                <label for="file">Documento a subir</label>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <input type="submit" value="Guardar" class="btn btn-primary" >
            <input type="reset" value="Limpiar" class="btn btn-danger">
        </div>

    </div>





</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyectol4\resources\views/project/file.blade.php ENDPATH**/ ?>