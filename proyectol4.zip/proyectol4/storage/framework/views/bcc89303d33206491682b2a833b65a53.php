
<?php $__env->startSection('contenido'); ?>

<h1>Crear un Nuevo Proyecto</h1>
<div class="container">
<!-- Mensajes de error sobre la validación -->
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>



    
<!-- Formulario para crear un proyecto y subir un archivo -->
<form class="form-floating" method="resource">
    <?php echo csrf_field(); ?>

    <?php if(isset($project)): ?>
    <?php echo method_field('put'); ?>
    <?php endif; ?>

   
    <div class="form-floating mb-3">
        <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre del producto" value="<?php echo e(isset($projects) ? $projects->nombre : old('nombre')); ?>">
        <label for="nombre">Nombre del proyecto</label>
    </div>

    <div class="row">
        <div class="col">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion" value="<?php echo e(isset($projects) ? $projects->descripcion : old('descripcion')); ?>">
                <label for="descripcion">Descripcion</label>
            </div>
        </div>
        <div class="col">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="p_v" name="estado" placeholder="Estado" value="<?php echo e(isset($projects) ? $projects->estado : old('estado')); ?>">
                <label for="p_v">Estado</label>
            </div>
        </div>
        <div class="col">
            <div class="form-floating mb-3">
                <input type="file" class="form-control" id="file" name="file" placeholder="Documento a subir" value="<?php echo e(isset($projects) ? $projects->file : old('file')); ?>">
                <label for="file">Documento</label>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <input type="submit" value="Guardar" class="btn btn-primary" >
            <input type="reset" value="Limpiar" class="btn btn-danger">
        </div>

    </div>





</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyectol4\resources\views/file/file.blade.php ENDPATH**/ ?>