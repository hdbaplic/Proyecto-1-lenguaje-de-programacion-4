
<?php $__env->startSection('contenido'); ?>

<h1>Gestion de Proyectos</h1>
<br>

<h4>Listado de Proyectos </h4>
<a class="btn btn-primary" href="<?php echo e(route('projects.Lista')); ?>">Ir a la lista de proyectos</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyectol4\resources\views/project/project.blade.php ENDPATH**/ ?>