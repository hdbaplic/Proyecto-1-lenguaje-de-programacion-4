
<?php $__env->startSection('contenido'); ?>


<h1>Gestion de proyectos <a class="btn btn-success" href="<?php echo e(route('projects.create')); ?>">Crear nuevo proyecto</a></h1>

<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<div class="row">
    <div class="col">

<table class="table" border="1">
    <thead>
        
    <tr>
        <th>Lista de proyectos</th>
        

    </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr> 
            <td><div class="card" style="width: 80rem;">
                <img src="imagen/proyecto.jpg" class="card-img-top" alt="..." height="200px">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($project->nombre); ?></h5>
                  <p class="card-text"><?php echo e($project->descripción); ?></p>
                  <p class="card-text"><strong>Estado: </strong><?php echo e($project->estado); ?></p>
                  <p class="card-text">
                      <strong>Archivo:</strong> 
                      <a href="<?php echo e(route('projects.download', ['project' => $project->id])); ?>">Descargar</a>
                  </p>

                  <a href="<?php echo e(route('projects.show', ['project' => $project->id])); ?>" class="btn btn-primary">Detalles</a>
                
                  <a href="<?php echo e(route('projects.edit', ['project' => $project->id])); ?>" class="btn btn-primary">Editar</a>

                  <form method="POST" action="<?php echo e(route('projects.destroy', ['project' => $project->id])); ?>" onsubmit="return confirm('Estas seguro que deseas eliminar este proyecto?')" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                  </form>
                </div>
              </div></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="4">No hay proyectos</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
</div>
<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php echo e($projects->links('pagination::bootstrap-5')); ?>



<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyectol4\resources\views/project/lista.blade.php ENDPATH**/ ?>