<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\File;
use App\Models\Project;
use Illuminate\Foundation\Testing\RefreshDatabase;

class FileTest extends TestCase
{
    use RefreshDatabase;

    public function test_crear_archivo_con_ruta()
    {
        // Asegurarte de que exista al menos un proyecto
        $project = Project::factory()->create();

        // Crear instancia del archivo
        $file = File::factory()->create([
            'project_id' => $project->id,
        ]);

        // Asignar ruta manualmente
        if ($file) {
            $file->ruta = 'storage/' . $file->nombre;
            $file->save();
        }

        // Verificar que se guardó correctamente
        $this->assertNotNull($file->ruta);
        $this->assertDatabaseHas('files', ['id' => $file->id, 'ruta' => 'ruta_del_archivo']);
    }
}
