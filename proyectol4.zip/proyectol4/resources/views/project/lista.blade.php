@extends('layouts.plantilla')
@section('contenido')


<h1>Gestion de proyectos <a class="btn btn-success" href="{{ route('projects.create') }}">Crear nuevo proyecto</a></h1>

@if(session('success'))
<div class="alert alert-success" role="alert">
    {{ session('success') }}
</div>
@endif
<div class="row">
    <div class="col">

<table class="table" border="1">
    <thead>
        
    <tr>
        <th>Lista de proyectos</th>
        

    </tr>
    </thead>
    <tbody>
    @forelse($projects as $project)
        <tr> 
            <td><div class="card" style="width: 80rem;">
                <img src="imagen/proyecto.jpg" class="card-img-top" alt="..." height="200px">
                <div class="card-body">
                  <h5 class="card-title">{{ $project->nombre }}</h5>
                  <p class="card-text">{{ $project->descripción }}</p>
                  <p class="card-text"><strong>Estado: </strong>{{ $project->estado }}</p>
                  <p class="card-text">
                      <strong>Archivo:</strong> 
                      <a href="{{ route('projects.download', ['project' => $project->id]) }}">Descargar</a>
                  </p>

                  <a href="{{route('projects.show', ['project' => $project->id])}}" class="btn btn-primary">Detalles</a>
                
                  <a href="{{ route('projects.edit', ['project' => $project->id]) }}" class="btn btn-primary">Editar</a>

                  <form method="POST" action="{{ route('projects.destroy', ['project' => $project->id]) }}" onsubmit="return confirm('Estas seguro que deseas eliminar este proyecto?')" style="display:inline;">
                    @csrf
                    @method('delete')
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                  </form>
                </div>
              </div></td>
        </tr>
    @empty
        <tr>
            <td colspan="4">No hay proyectos</td>
        </tr>
    @endforelse
    </tbody>
</table>
</div>
@if (session('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    {{ session('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

{{ $projects->links('pagination::bootstrap-5') }}


@endsection
 