@extends('layouts.plantilla')
@section('contenido')

@isset($project)
<h1>Editar Proyecto {{ $project->nombre }} <a class="btn btn-success" href="{{ route('projects.index') }}">Volver</a></h1>
@else
<h1>Crear un Nuevo Proyecto <a class="btn btn-success" href="{{ route('projects.index') }}">Volver</a></h1>
@endisset
<div class="container">
<!-- Mensajes de error sobre la validación -->
@if ($errors->any())
<div class="alert alert-danger">
    <ul>
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif



    
<!-- Formulario para crear un proyecto y subir un archivo -->
<form class="form-floating" method="post" enctype="multipart/form-data">
    
    @csrf
    <input type="hidden" name="_method" value="PUT">
    @isset($project)
    @method('put')
    @endisset

   
    <div class="form-floating mb-3">
        <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre del producto" value="{{ isset($project) ? $project->nombre : old('nombre') }}">
        <label for="nombre">Nombre del proyecto</label>
    </div>

    <div class="row">
        <div class="col">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion" value="{{ isset($project) ? $project->descripcion : old('descripcion') }}">
                <label for="descripcion">Descripcion</label>
            </div>
        </div>
        <div class="col">

            <div class="form-floating mb-3">
                
                <select name="estado" id="estado" class="form-select" required>
                    <option value="activo" {{isset($project) && $project->estado == 'activo' ? 'selected' : ''}} placeholder="Estado">Activo</option>
                    <option value="completado" {{isset($project) && $project->estado == 'completado' ? 'selected' : ''}}>Completado</option>
                </select>
                <label for="estado">Estado</label>
            </div>
        </div>
        <div class="col">
            <div class="form-floating mb-3">
                <input type="file" class="form-control" id="file" name="ruta" placeholder="Documento a subir" value="{{isset($project) ? $project->ruta : old('ruta') }}">
                <label for="file">Documento a subir</label>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <input type="submit" value="Guardar" class="btn btn-primary" >
            <input type="reset" value="Limpiar" class="btn btn-danger">
        </div>

    </div>





</form>
</div>


@endsection