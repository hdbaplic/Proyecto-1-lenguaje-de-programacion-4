@extends('layouts.plantilla')
@section('contenido')

<h1>Proyecto {{ $project->nombre }} </h1>
<div class="container">
    <div class="row">
        <div class="col">
            <div class="card" style="width: 80rem;">
                <div class="card-body">
                  <h5 class="card-title"><strong>Nombre:  </strong>{{ $project->nombre }}</h5>
                  <p class="card-text"><strong>Descripción: </strong> <br>{{ $project->descripcion }}</p>
                  <p class="card-text"><strong>Estado: </strong>{{ $project->estado }}</p>
                  <p class="card-text">
                      <strong>Archivo:</strong> 
                      <a href="{{ route('projects.show', ['project' => $project->id]) }}">Ver Proyecto</a>
                  </p>
                
                
                </div>
              </div>
        </div>
    </div>
</div>



<div class="container">
    <h2>Lista de comentarios</h2>
   
    <table class="table">
        <thead>
            <tr>
                <th>Comentario</th>
                <th>Nombre</th>
                <th>Id de usuario</th>
                <th>Id de proyecto</th>
                
               
            </tr>
        </thead>
        <tbody>
            @forelse($project->comments as $comentario)
            <tr>
                <td>{{ $comentario->contenido }}</td>
                <td>{{ $comentario->name }}</td>
                <td>{{ $comentario->id }}</td>
                <td>{{ $comentario->id }}</td>
            </tr>
            @empty
                <tr>
                    <td colspan="4">No hay comentarios</td>
                </tr>
            
            @endforelse
        </tbody>
        
    </table>
        
   
</div>
<a href="{{ route('projects.index') }}" class="btn btn-primary">Volver</a>

@endsection