<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Project;

class File extends Model
{
    use HasFactory;

    protected $fillable = ['nombre', 'descripcion', 'project_id'];

    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    
}
