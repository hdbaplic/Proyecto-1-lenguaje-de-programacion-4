<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\File;

class ProjectController extends Controller
{
    public function index()
    {
        $projects = Project::paginate(8);
        return view('project.lista')->with('projects', $projects);
    
    }

    public function show($id){

        $project = Project::find($id);
        return view('project.show')->with('project', $project);
    }

    public function create(){
    
        return view('project.file');
    }

   

    public function store(Request $request)
    {
         // Validar el formulario
         $request->validate([
            'nombre' => 'required|string|max:255',
            'project_id' => 'required|exists:projects,id',
        ]);

        // Crear archivo
        $file = File::factory()->create([
            'nombre' => $request->nombre,
            'project_id' => $request->project_id,
        ]);

        // Asignar ruta manualmente
        if ($file) {
            $file->ruta = 'storage/' . $file->nombre;
            $file->save();
        }

        return redirect()->back()->with('success', 'Archivo creado con éxito');
    }

    public function destroy($id)
    {
        $project = Project::find($id);
        $project->delete();
        return redirect()->back()->with('success', 'Proyecto eliminado con éxito');
    }

    public function edit($id)
    {
        $project = Project::find($id);
        return view('project.file')->with('project', $project);
    }   

    public function update(Request $request, $id)
    {
        $project = Project::find($id);
        $request->validate([
            'nombre' => 'required|string|max:255',
            'project_id' => 'required|exists:projects,id',
        ]);

        // Crear archivo
        $file = File::factory()->create([
            'nombre' => $request->nombre,
            'project_id' => $request->project_id,
        ]);

        // Asignar ruta manualmente
        if ($file) {
            $file->ruta = 'storage/' . $file->nombre;
            $file->save();
        }

        return redirect()->back()->with('success', 'Archivo creado con éxito');   
    }
    
    
    

    public function download($id){
        $project = Project::find($id);
        $filePath = public_path(). '/storage/'. $project->ruta;
        if(file_exists($filePath)){
            return response()->download($filePath);
        }else{
            return redirect()->route('projects.index')->with('error', 'El archivo '. $projects->file. ' no existe');
        }
    }
    
}
