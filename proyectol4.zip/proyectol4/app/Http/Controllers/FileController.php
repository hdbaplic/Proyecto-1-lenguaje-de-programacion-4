<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\File;
use App\Models\Project;

class FileController extends Controller
{
    public function index(){
        return view('file.file');
    }

    public function create(){
        return view('project.file');
    }


        public function store(Request $request)
        {
            // Validar el formulario
            $request->validate([
                'nombre' => 'required|string|max:255',
                'project_id' => 'required|exists:projects,id',
            ]);
    
            // Crear archivo
            $file = File::factory()->create([
                'nombre' => $request->nombre,
                'project_id' => $request->project_id,
            ]);
    
            // Asignar ruta manualmente
            if ($file) {
                $file->ruta = 'storage/' . $file->nombre;
                $file->save();
            }
    
            return redirect()->back()->with('success', 'Archivo creado con éxito');
        }
    
    
   
}
