<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Project;
use App\Models\User;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class ProjectFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {

        
           
        
            
        return [
            'nombre' => $this->faker->sentence(3),
            'descripcion' => $this->faker->paragraph,
            'estudiante_id' => User::factory(), // Crea un nuevo usuario para el estudiante
            'profesor_id' => User::factory(), // Crea un nuevo usuario para el profesor
            'estado' => $this->faker->randomElement(['activo', 'completado']),
        ];
            
        
    }
}
