<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\File;
use App\Models\Project;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\File>
 */
class FileFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
           'nombre' => $this->faker->word() . '.' . $this->faker->fileExtension(), // Genera un nombre de archivo falso
        'ruta' => 'files/' . $this->faker->unique()->lexify('??????') . '.' . $this->faker->fileExtension(), // Ruta simulada
        'project_id' => Project::all()->random()->id,
        ];
    }
}
