<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Project;


class TableUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::factory()->count(5)->create(['rol' => 'profesor']);

        // Crear estudiantes
        $estudiante = User::factory()->count(20)->create(['rol' => 'estudiante']);

        // Crear proyectos
        $estudiante->each(function ($estudiante) {
            Project::factory()->count(20)->create([
                'estudiante_id' => $estudiante->id,
                'profesor_id' => User::where('rol', 'profesor')->inRandomOrder()->first()->id,
            ]);
        });
    }
}
