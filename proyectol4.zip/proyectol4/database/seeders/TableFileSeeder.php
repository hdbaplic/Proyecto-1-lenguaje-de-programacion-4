<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\File;
use App\Models\Project;
class TableFileSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // Crear un proyecto para asociar archivos
        $project = Project::factory()->create();

        // Crear 10 archivos asociados al proyecto
        for ($i = 0; $i < 10; $i++) {
            $file = File::factory()->create([
                'project_id' => $project->id,
            ]);

            // Asignar una ruta manualmente
            if ($file) {
                $file->ruta = 'ruta_del_archivo_' . $i;
                $file->save();
            }
        }
    }
}
